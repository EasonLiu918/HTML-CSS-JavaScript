// This function defines the Fire module.
// - `ctx` - A canvas context for drawing
// - `x` - The initial x position of the fire
// - `y` - The initial y position of the fire

const Fire = function(ctx, x, y){
	
	
	const sprite = Sprite(ctx, x, y);
	
	
    // The sprite object is configured for the gem sprite here.
    sprite.setSequence({x: 0, y: 160, width: 32, height: 32, count: 8, timing: 100})
          .setScale(2)
          .useSheet("object_sprites.png");	
		  
    return {
        setXY: sprite.setXY,
        draw: sprite.draw,
        update: sprite.update
    };
};